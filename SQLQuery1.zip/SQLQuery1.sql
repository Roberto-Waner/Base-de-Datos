Use Panederia

create table Productos(
	id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	nombre_producto VARCHAR(100) NOT NULL,
	tipo VARCHAR(100),
	descripcion VARCHAR(255),
	ingredientes VARCHAR(255),
	precio DECIMAL(6,2) NOT NULL,
	imagen VARCHAR(MAX)
);

select * from Productos

-- Procedimiento almacenados
--Insertar
CREATE PROCEDURE spInserta_Producto
	@nombre_producto VARCHAR(100),
	@tipo VARCHAR(100),
	@descripcion VARCHAR(255),
	@ingredientes VARCHAR(255),
	@precio DECIMAL(6,2),
	@imagen VARCHAR(MAX)
AS
BEGIN
	INSERT INTO Productos(nombre_producto, tipo, descripcion, ingredientes, precio, imagen)
	VALUES (@nombre_producto, @tipo, @descripcion, @ingredientes, @precio, @imagen)
END

--consultar
create procedure spConsultar_Producto
	@id int
as
begin
	select * from Productos where id = @id
end

--actualizar
create procedure spActualizar_Producto
	@id INT,
    @nombre_producto VARCHAR(100),
    @tipo VARCHAR(100),
    @descripcion VARCHAR(255),
    @ingredientes VARCHAR(255),
    @precio DECIMAL(6,2),
    @imagen VARCHAR(MAX)
as
begin
	update Productos
	set nombre_producto = @nombre_producto,
		tipo = @tipo,
		descripcion = @descripcion,
		ingredientes = @ingredientes,
		precio = @precio,
		imagen = @imagen
	where id = @id
end

--eliminar
create procedure spEliminar_Producto
	@id int
as
begin
	delete from Productos
	where id = @id
end


-- Prueva
execute spConsultar_Producto '1'